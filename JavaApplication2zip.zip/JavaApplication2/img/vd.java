package com.mycompany.doan.img;
import javax.swing.*;
import java.awt.*;

public class vd {
    public static void main(String[] args) {
        // Tạo một JFrame
        JFrame frame = new JFrame("Image Label Example");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 300);
        
        // Tạo một ImageIcon từ tệp hình ảnh
        ImageIcon icon = new ImageIcon("add1.png");
        
        // Tạo một JLabel và đặt biểu tượng vào đó
        JLabel label = new JLabel(icon);
        
        // Thêm nhãn vào khung
        frame.getContentPane().add(label, BorderLayout.CENTER);
        
        // Hiển thị khung
        frame.setVisible(true);
    }
}
