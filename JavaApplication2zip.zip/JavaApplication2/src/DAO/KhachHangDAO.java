/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import DTO.KhachHangDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author PC
 */
public class KhachHangDAO {
    
    private ConnectDataBaseDB connectDB;
    
    public KhachHangDAO() {
        try {
            connectDB = new ConnectDataBaseDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
   public List<KhachHangDTO> getAllKhachHang(){
    List<KhachHangDTO> danhSachKhachHang = new ArrayList<>();
    String query = "SELECT * FROM khach_hang";
    try (ResultSet resultSet = connectDB.executeSelect(query)){
        while (resultSet.next()){
            KhachHangDTO khachHang = new KhachHangDTO();
            khachHang.setMaKhachHang(resultSet.getString("MAKH"));
            khachHang.setTenKhachHang(resultSet.getString("TENKH"));
            khachHang.setsDT(resultSet.getInt("SDT"));
            khachHang.setDiaChi(resultSet.getString("DIACHI"));
            khachHang.setLoaiThanhVien(resultSet.getString("LOAITHANHVIEN"));
            
            // Thêm khách hàng vào danh sách
            danhSachKhachHang.add(khachHang);
        }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSachKhachHang;
    }
    public void addKhachHang(KhachHangDTO khachHang){
        String query = "INSERT INTO khach_hang (MAKH,TENKH,STD,DIACHI,LOAITHANHVIEN) VALUES (?,?,?,?,?)";
        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, khachHang.getMaKhachHang());
            preparedStatement.setString(2, khachHang.getTenKhachHang());
            preparedStatement.setInt(3, khachHang.getsDT());
            preparedStatement.setString(4, khachHang.getDiaChi());
            preparedStatement.setString(5, khachHang.getLoaiThanhVien());
            
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void updateKhachHang(KhachHangDTO khachHang) {
        String query = "UPDATE khach_hang SET TENKH = ?, SDT = ?, DIACHI = ?, LOAITHANHVIEN = ? WHERE MAKH = ?";

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, khachHang.getTenKhachHang());
            preparedStatement.setInt(2, khachHang.getsDT());
            preparedStatement.setString(3, khachHang.getDiaChi());
            preparedStatement.setString(4, khachHang.getLoaiThanhVien());
            preparedStatement.setString(5, khachHang.getMaKhachHang());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

     public void deleteKhachHang(String maKH) {
        String query = "DELETE FROM khach_hang WHERE MAKH = ?";

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, maKH);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
      public KhachHangDTO getKhachHangById(String maKH) {
        String query = "SELECT * FROM khach_hang WHERE MAKH = ?";
        KhachHangDTO khachHang = null;

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, maKH);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    
                    khachHang = new KhachHangDTO();
                    khachHang.setMaKhachHang(resultSet.getString("MAKH"));
                    khachHang.setTenKhachHang(resultSet.getString("TENKH"));
                    khachHang.setsDT(resultSet.getInt("SDT"));
                    khachHang.setDiaChi(resultSet.getString("DIACHI"));
                    khachHang.setLoaiThanhVien(resultSet.getString("LOAITHANHVIEN"));

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return khachHang;
    }
}
