/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

/**
 *
 * @author PC
 */

import DTO.NhanVienDTO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NhanVienDAO {

    private ConnectDataBaseDB connectDB;

    public NhanVienDAO() {
        try {
            connectDB = new ConnectDataBaseDB();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<NhanVienDTO> getAllNhanVien() {
        List<NhanVienDTO> danhSachNhanVien = new ArrayList<>();
        String query = "SELECT * FROM nhan_vien";

        try (ResultSet resultSet = connectDB.executeSelect(query)) {
            while (resultSet.next()) {
                NhanVienDTO nhanVien = new NhanVienDTO();
                nhanVien.setMaNhanVien(resultSet.getString("ma_nhan_vien"));
                nhanVien.setTenNhanVien(resultSet.getString("ten_nhan_vien"));
                nhanVien.setNgaySinh(resultSet.getString("ngay_sinh"));
                nhanVien.setDiaChi(resultSet.getString("dia_chi"));
                danhSachNhanVien.add(nhanVien);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return danhSachNhanVien;
    }

    public void addNhanVien(NhanVienDTO nhanVien) {
        String query = "INSERT INTO nhan_vien (ma_nhan_vien, ten_nhan_vien, ngay_sinh, dia_chi) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, nhanVien.getMaNhanVien());
            preparedStatement.setString(2, nhanVien.getTenNhanVien());
            preparedStatement.setString(3, nhanVien.getNgaySinh());
            preparedStatement.setString(4, nhanVien.getDiaChi());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateNhanVien(NhanVienDTO nhanVien) {
        String query = "UPDATE nhan_vien SET ten_nhan_vien = ?, ngay_sinh = ?, dia_chi = ? WHERE ma_nhan_vien = ?";

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, nhanVien.getTenNhanVien());
            preparedStatement.setString(2, nhanVien.getNgaySinh());
            preparedStatement.setString(3, nhanVien.getDiaChi());
            preparedStatement.setString(4, nhanVien.getMaNhanVien());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteNhanVien(String maNhanVien) {
        String query = "DELETE FROM nhan_vien WHERE ma_nhan_vien = ?";

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, maNhanVien);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public NhanVienDTO getNhanVienById(String maNhanVien) {
        String query = "SELECT * FROM nhan_vien WHERE ma_nhan_vien = ?";
        NhanVienDTO nhanVien = null;

        try (PreparedStatement preparedStatement = connectDB.getConnection().prepareStatement(query)) {
            preparedStatement.setString(1, maNhanVien);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    nhanVien = new NhanVienDTO();
                    nhanVien.setMaNhanVien(resultSet.getString("ma_nhan_vien"));
                    nhanVien.setTenNhanVien(resultSet.getString("ten_nhan_vien"));
                    nhanVien.setNgaySinh(resultSet.getString("ngay_sinh"));
                    nhanVien.setDiaChi(resultSet.getString("dia_chi"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return nhanVien;
    }
}
