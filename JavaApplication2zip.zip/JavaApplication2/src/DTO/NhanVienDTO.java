/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DTO;

/**
 *
 * @author PC
 */public class NhanVienDTO {
    private String maNhanVien;
    private String tenNhanVien;
    private String ngaySinh;
    private String diaChi;
//    private String ngayNhapViec;

    
    
    public NhanVienDTO(String maNhanVien, String hoTen, String diaChi, String ngaySinh) {
        // Khởi tạo các thuộc tính của NhanVienDTO bằng các giá trị tham số
        this.maNhanVien = maNhanVien;
        this.tenNhanVien = hoTen;
        this.diaChi = diaChi;
        this.ngaySinh = ngaySinh;
    }

    public NhanVienDTO() {

    }
    public String getMaNhanVien() {
        return maNhanVien;
    }

    public void setMaNhanVien(String maNhanVien) {
        this.maNhanVien = maNhanVien;
    }

    public String getTenNhanVien() {
        return tenNhanVien;
    }

    public void setTenNhanVien(String tenNhanVien) {
        this.tenNhanVien = tenNhanVien;
    }

    public String getNgaySinh() {
        return ngaySinh;
    }

    public void setNgaySinh(String ngaySinh) {
        this.ngaySinh = ngaySinh;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

//    public String getNgayNhapViec() {
//        return ngayNhapViec;
//    }
//
//    public void setNgayNhapViec(String ngayNhapViec) {
//        this.ngayNhapViec = ngayNhapViec;
//    }
//    
    
}
