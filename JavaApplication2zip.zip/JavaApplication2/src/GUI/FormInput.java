///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package GUI;
//
///**
// *
// * @author PC
// */
//import javax.swing.*;
//import java.awt.*;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//import vd.NhanVien;
//
//public class FormInput extends JDialog {
//    private JTextField txtID, txtName, txtAge, txtPosition;
//    private JButton btnSubmit, btnCancel;
//    private NhanVien parentPanel;
//    private String actionType;
//    private int selectedRow = -1;
//
//    public FormInput(JFrame parentFrame, String actionType, NhanVien parentPanel) {
//        super(parentFrame, true);
//        this.actionType = actionType;
//        this.parentPanel = parentPanel;
//
//        setTitle(actionType + " Nhân Viên");
//        setSize(300, 200);
//        setLayout(new GridLayout(5, 2));
//
//        // Tạo các trường nhập dữ liệu
//        txtID = new JTextField();
//        txtName = new JTextField();
//        txtAge = new JTextField();
//        txtPosition = new JTextField();
//
//        btnSubmit = new JButton("Submit");
//        btnCancel = new JButton("Cancel");
//
//        // Thêm các trường vào form
//        add(new JLabel("ID:"));
//        add(txtID);
//        add(new JLabel("Name:"));
//        add(txtName);
//        add(new JLabel("Age:"));
//        add(txtAge);
//        add(new JLabel("Position:"));
//        add(txtPosition);
//        add(btnSubmit);
//        add(btnCancel);
//
//        // Thêm sự kiện cho các nút
//        btnSubmit.addActionListener(e -> handleSubmit());
//        btnCancel.addActionListener(e -> dispose());
//
//        // Kiểm tra nếu đang chỉnh sửa một nhân viên
//        if (actionType.equals("Sửa")) {
//            selectedRow = parentPanel.table.getSelectedRow();
//            if (selectedRow != -1) {
//                txtID.setText(String.valueOf(parentPanel.table.getValueAt(selectedRow, 0)));
//                txtName.setText(String.valueOf(parentPanel.table.getValueAt(selectedRow, 1)));
//                txtAge.setText(String.valueOf(parentPanel.table.getValueAt(selectedRow, 2)));
//                txtPosition.setText(String.valueOf(parentPanel.table.getValueAt(selectedRow, 3)));
//            }
//        }
//    }
//
//    // Xử lý sự kiện khi nhấn nút Submit
//    private void handleSubmit() {
//        int id = Integer.parseInt(txtID.getText());
//        String name = txtName.getText();
//        int age = Integer.parseInt(txtAge.getText());
//        String position = txtPosition.getText();
//
//        // Thực hiện hành động dựa trên loại thao tác (Thêm, Xóa, Sửa)
//        if (actionType.equals("Thêm")) {
//            parentPanel.addEmployee(id, name, age, position);
//        } else if (actionType.equals("Sửa")) {
//            parentPanel.updateEmployee(selectedRow, id, name, age, position);
//        } else if (actionType.equals("Xóa")) {
//            parentPanel.deleteEmployee(selectedRow);
//        }
//
//        // Đóng form sau khi xử lý
//        dispose();
//    }
//}
