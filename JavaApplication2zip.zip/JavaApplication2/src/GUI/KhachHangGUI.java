package GUI;

import BUS.KhachHangBUS;
import DTO.KhachHangDTO;

import java.awt.*;
import java.sql.SQLException;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class KhachHangGUI extends JPanel {
    private KhachHangBUS khachHangBUS;
    private DefaultTableModel model;
    private JTable table;

    private JTextField txtMaKhachHang, txtTenKhachHang, txtSDT, txtDiaChi, txtLoaiThanhVien;

    public KhachHangGUI() {
        khachHangBUS = new KhachHangBUS();
        initUI();
        loadKhachHangData();
    }

    private void initUI() {
        setLayout(new BorderLayout(5, 5));
        setBackground(new Color(250, 250, 250));

        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(1, 5, 5, 5));
        controlPanel.setBackground(new Color(250, 250, 250));
        controlPanel.setPreferredSize(new Dimension(1280, 70));

        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnTimKiem = new JButton("Tìm kiếm");
        JButton btnLamMoi = new JButton("Làm mới");

        controlPanel.add(btnThem);
        controlPanel.add(btnSua);
        controlPanel.add(btnXoa);
        controlPanel.add(btnTimKiem);
        controlPanel.add(btnLamMoi);

        add(controlPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(5, 2, 5, 5));
        inputPanel.setBackground(new Color(250, 250, 250));

        inputPanel.add(new JLabel("Mã Khách Hàng "));
        txtMaKhachHang = new JTextField(20);
        inputPanel.add(txtMaKhachHang);

        inputPanel.add(new JLabel("Họ và Tên  "));
        txtTenKhachHang = new JTextField(20);
        inputPanel.add(txtTenKhachHang);

        inputPanel.add(new JLabel("Số điện thoại "));
        txtSDT = new JTextField(20);
        inputPanel.add(txtSDT);

        inputPanel.add(new JLabel("Địa Chỉ "));
        txtDiaChi = new JTextField(20);
        inputPanel.add(txtDiaChi);

        inputPanel.add(new JLabel("loại Thành Viên "));
        txtLoaiThanhVien = new JTextField(20);
        inputPanel.add(txtLoaiThanhVien);
        inputPanel.setPreferredSize(new Dimension(1280,300));
        add(inputPanel, BorderLayout.SOUTH);

        // Xử lý sự kiện cho các nút
        btnThem.addActionListener(e -> addKhachHang());
        btnSua.addActionListener(e -> updateKhachHang());
        btnXoa.addActionListener(e -> deleteKhachHang());
        btnLamMoi.addActionListener(e -> clearInputs());
        btnTimKiem.addActionListener(e -> searchKhachHang());

        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[]{"Mã Khách hàng", "Họ và Tên", "Số Điện Thoại", "Địa chỉ", "Loại Thanh Viên"});
        table = new JTable(model);
        table.setBackground(new Color(250, 250, 250));
        table.setForeground(Color.PINK);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        JScrollPane sp = new JScrollPane(table);
        sp.getViewport().setBackground(Color.WHITE);
        add(sp, BorderLayout.CENTER);
    }

    private void loadKhachHangData() {
        try {
            List<KhachHangDTO> danhSachKhachHang = khachHangBUS.getAllKhachHang();
            for (KhachHangDTO kh : danhSachKhachHang) {
                model.addRow(new Object[]{kh.getMaKhachHang(), kh.getTenKhachHang(), kh.getsDT(), kh.getDiaChi(), kh.getLoaiThanhVien()});
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi khi tải dữ liệu khách hàng: " + ex.getMessage(), "Lỗi", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addKhachHang() {
        String maKhachHang = txtMaKhachHang.getText();
        String tenKhachHang = txtTenKhachHang.getText();
        int sDT = Integer.parseInt(txtSDT.getText());
        String diaChi = txtDiaChi.getText();
        String loaiThanhVien = txtLoaiThanhVien.getText();

        KhachHangDTO kh = new KhachHangDTO(maKhachHang, tenKhachHang, sDT, diaChi, loaiThanhVien);

        khachHangBUS.addKhachHang(kh);
        model.addRow(new Object[]{maKhachHang, tenKhachHang, sDT, diaChi, loaiThanhVien});
        clearInputs();
    }

    private void updateKhachHang() {
        String maKhachHang = txtMaKhachHang.getText();
        String tenKhachHang = txtTenKhachHang.getText();
        int sDT = Integer.parseInt(txtSDT.getText());
        String diaChi = txtDiaChi.getText();
        String loaiThanhVien = txtLoaiThanhVien.getText();

        KhachHangDTO kh = new KhachHangDTO(maKhachHang, tenKhachHang, sDT, diaChi, loaiThanhVien);

        khachHangBUS.upadateKhachHang(kh);

        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            model.setValueAt(tenKhachHang, selectedRow, 1);
            model.setValueAt(sDT, selectedRow, 2);
            model.setValueAt(diaChi, selectedRow, 3);
            model.setValueAt(loaiThanhVien, selectedRow, 4);
        }

        // Xóa các trường nhập
        clearInputs();
    }

    private void deleteKhachHang() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String maKhachHang = (String) model.getValueAt(selectedRow, 0);

            // Xóa nhân viên khỏi cơ sở dữ liệu
            khachHangBUS.deleteKhachHang(maKhachHang);

            // Xóa dữ liệu khỏi bảng
            model.removeRow(selectedRow);
        }
    }

    private void searchKhachHang() {
        String maKhachHang = txtMaKhachHang.getText();

        KhachHangDTO kh = khachHangBUS.getKhachHangById(maKhachHang);
        if (kh != null) {
            // Xóa các hàng hiện có
            model.setRowCount(0);

            // Thêm dữ liệu của nhân viên tìm thấy vào bảng
            model.addRow(new Object[]{kh.getMaKhachHang(), kh.getTenKhachHang(), kh.getsDT(), kh.getDiaChi(), kh.getLoaiThanhVien()});
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy nhân viên có mã: " + maKhachHang);
        }

        // Xóa các trường nhập
        clearInputs();
    }

    // Xóa các trường nhập dữ liệu
    private void clearInputs() {
        txtMaKhachHang.setText("");
        txtTenKhachHang.setText("");
        txtSDT.setText("");
        txtDiaChi.setText("");
        txtLoaiThanhVien.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Quản lý khách hàng");
            KhachHangGUI gui = new KhachHangGUI();
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.add(gui);
            frame.setSize(800, 600);
            frame.setVisible(true);
        });
    }
}
