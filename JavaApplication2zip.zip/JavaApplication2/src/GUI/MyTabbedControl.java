///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package GUI;
//
///**
// *
// * @author PC
// */
//
//
//import javax.swing.*;
//import java.awt.*;
//
//public class MyTabbedControl extends JFrame {
//
//    public MyTabbedControl(String title) {
//        super(title);
//        setSize(400, 300);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        add(new MyTabbedPane());
//        setVisible(true);
//    }
//
//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> {
//            new MyTabbedControl("My Tabbed");
//        });
//    }
//}
