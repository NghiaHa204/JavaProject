///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package GUI;
//
///**
// *
// * @author PC
// */
//
//
//import javax.swing.*;
//import java.awt.*;
//
//public class MyTabbedPane extends JPanel {
//
//    public MyTabbedPane() {
//        setLayout(new BorderLayout());
//
//        JTabbedPane tabbedPane = new JTabbedPane();
//
//        JPanel tab1 = new JPanel();
//        tab1.setBackground(Color.BLUE);
//        tab1.add(new JButton("Tab 1"));
//        tabbedPane.addTab("Tab 1", tab1);
//
//        JPanel tab2 = new JPanel();
//        tab2.setBackground(Color.ORANGE);
//        tab2.add(new JButton("Tab 2"));
//        tabbedPane.addTab("Tab 2", tab2);
//
//        add(tabbedPane, BorderLayout.CENTER);
//    }
//}
