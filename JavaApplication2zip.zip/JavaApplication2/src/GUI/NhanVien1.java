///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package GUI;
//
//import javax.swing.JFrame;
//import javax.swing.JPanel;
//
///**
// *
// * @author PC
// */
//public class NhanVien1 extends JPanel{
//    public NhanVien1(String title) {
//        super(title);
//        setSize(400, 300);
//        setLocationRelativeTo(null);
//        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        add(new MyTabbedPane());
//        setVisible(true);
//    }
//    
//}
