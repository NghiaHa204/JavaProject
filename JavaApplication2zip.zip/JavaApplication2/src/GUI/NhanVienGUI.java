/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package GUI;

/**
 *
 * @author PC
 */

import BUS.NhanVienBUS;
import DTO.NhanVienDTO;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class NhanVienGUI extends JPanel {
    private NhanVienBUS nhanVienBUS;
    private DefaultTableModel model;
    private JTable table;
    private JTextField txtMaNhanVien, txtHoTen, txtDiaChi, txtNgaySinh;
    
    // Constructor
    public NhanVienGUI() {
        nhanVienBUS = new NhanVienBUS();
        initUI();
        loadNhanVienData();
    }
   

    
    // Khởi tạo giao diện
    private void initUI() {
        setLayout(new BorderLayout(5, 5));
        
        // Khởi tạo bảng dữ liệu
        model = new DefaultTableModel();
        model.setColumnIdentifiers(new String[] {"Mã Nhân Viên", "Họ và Tên", "Địa Chỉ", "Ngày Sinh"});
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        add(sp, BorderLayout.CENTER);
        
        // Khởi tạo bảng điều khiển dưới cùng
        JPanel controlPanel = new JPanel();
        controlPanel.setLayout(new GridLayout(1, 5, 5, 5));
        
        // Khởi tạo và thêm các nút vào bảng điều khiển
        JButton btnThem = new JButton("Thêm");
        JButton btnSua = new JButton("Sửa");
        JButton btnXoa = new JButton("Xóa");
        JButton btnTimKiem = new JButton("Tìm kiếm");
        JButton btnLamMoi = new JButton("Làm mới");
        
        controlPanel.add(btnThem);
        controlPanel.add(btnSua);
        controlPanel.add(btnXoa);
        controlPanel.add(btnTimKiem);
        controlPanel.add(btnLamMoi);
        
        add(controlPanel, BorderLayout.SOUTH);
        
        // Khởi tạo các trường nhập dữ liệu
        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(4, 2, 5, 5));
        
        inputPanel.add(new JLabel("Mã Nhân Viên"));
        txtMaNhanVien = new JTextField(20);
        inputPanel.add(txtMaNhanVien);
        
        inputPanel.add(new JLabel("Họ và Tên"));
        txtHoTen = new JTextField(20);
        inputPanel.add(txtHoTen);
        
        inputPanel.add(new JLabel("Địa Chỉ"));
        txtDiaChi = new JTextField(20);
        inputPanel.add(txtDiaChi);
        
        inputPanel.add(new JLabel("Ngay Sinh"));
        txtNgaySinh = new JTextField(20);
        inputPanel.add(txtNgaySinh);
        
        add(inputPanel, BorderLayout.NORTH);
        
        // Thêm sự kiện cho các nút
        btnThem.addActionListener(e -> addNhanVien());
        btnSua.addActionListener(e -> updateNhanVien());
        btnXoa.addActionListener(e -> deleteNhanVien());
        btnLamMoi.addActionListener(e -> clearInputs());
        btnTimKiem.addActionListener(e -> searchNhanVien());
    }
    
    // Load dữ liệu nhân viên vào bảng
    private void loadNhanVienData() {
        List<NhanVienDTO> danhSachNhanVien = nhanVienBUS.getAllNhanVien();
        for (NhanVienDTO nv : danhSachNhanVien) {
            model.addRow(new Object[] {nv.getMaNhanVien(), nv.getTenNhanVien(), nv.getDiaChi(), nv.getNgaySinh()});
        }
    }
    
    // Thêm một nhân viên mới
    private void addNhanVien() {
        // Lấy thông tin từ các trường nhập
        String maNhanVien = txtMaNhanVien.getText();
        String tenNhanVien = txtHoTen.getText();
        String diaChi = txtDiaChi.getText();
        String ngaySinh = txtNgaySinh.getText();
        
        // Tạo một đối tượng nhân viên DTO
        NhanVienDTO nv = new NhanVienDTO(maNhanVien, tenNhanVien, diaChi, ngaySinh);
        
        // Thêm nhân viên vào cơ sở dữ liệu
        nhanVienBUS.addNhanVien(nv);
        
        // Cập nhật bảng dữ liệu
        model.addRow(new Object[] {maNhanVien, tenNhanVien, diaChi, ngaySinh});
        
        // Xóa các trường nhập
        clearInputs();
    }
    
    // Sửa một nhân viên
    private void updateNhanVien() {
        // Lấy thông tin từ các trường nhập
        String maNhanVien = txtMaNhanVien.getText();
        String tenNhanVien = txtHoTen.getText();
        String diaChi = txtDiaChi.getText();
        String ngaySinh = txtNgaySinh.getText();
        
        // Tạo một đối tượng nhân viên DTO
        NhanVienDTO nv = new NhanVienDTO(maNhanVien, tenNhanVien, diaChi, ngaySinh);
        
        // Sửa nhân viên trong cơ sở dữ liệu
        nhanVienBUS.updateNhanVien(nv);
        
        // Cập nhật dữ liệu trên bảng
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            model.setValueAt(tenNhanVien, selectedRow, 1);
            model.setValueAt(diaChi, selectedRow, 2);
            model.setValueAt(ngaySinh, selectedRow, 3);
        }
        
        // Xóa các trường nhập
        clearInputs();
    }
    
    // Xóa một nhân viên
    private void deleteNhanVien() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            String maNhanVien = (String) model.getValueAt(selectedRow, 0);
            
            // Xóa nhân viên khỏi cơ sở dữ liệu
            nhanVienBUS.deleteNhanVien(maNhanVien);
            
            // Xóa dữ liệu khỏi bảng
            model.removeRow(selectedRow);
        }
    }
    
    // Tìm kiếm một nhân viên
    private void searchNhanVien() {
        String maNhanVien = txtMaNhanVien.getText();
        
        NhanVienDTO nv = nhanVienBUS.getNhanVienById(maNhanVien);
        if (nv != null) {
            // Xóa các hàng hiện có
            model.setRowCount(0);
            
            // Thêm dữ liệu của nhân viên tìm thấy vào bảng
            model.addRow(new Object[] {nv.getMaNhanVien(), nv.getTenNhanVien(), nv.getDiaChi(), nv.getNgaySinh()});
        } else {
            JOptionPane.showMessageDialog(this, "Không tìm thấy nhân viên có mã: " + maNhanVien);
        }
        
        // Xóa các trường nhập
        clearInputs();
    }
    
    // Xóa các trường nhập dữ liệu
    private void clearInputs() {
        txtMaNhanVien.setText("");
        txtHoTen.setText("");
        txtDiaChi.setText("");
        txtNgaySinh.setText("");
    }
    
    // Khởi chạy chương trình
//    public static void main(String[] args) {
//        JFrame frame = new JFrame("Quản lý nhân viên");
//        NhanVienGUI gui = new NhanVienGUI();
//        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        frame.add(gui);
//        frame.setSize(800, 600);
//        frame.setVisible(true);
//    }
}
