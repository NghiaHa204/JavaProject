/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;


/**
 *
 * @author THANHSANG
 */
import com.mysql.jdbc.Driver;

import java.sql.*;

public class ConnectDataBaseDB {
   private Connection conn;
   private String url;
   private String dbName;
   private String driver;
   private String userName; 
   private String password;

   public ConnectDataBaseDB() throws SQLException
   {
      //driver = new org.gjt.mm.mysql.Driver();
       url = "jdbc:mysql://localhost:3306/";
       dbName = "mysql";
       driver = "com.mysql.jdbc.Driver";
       userName = "root";
       password = "";
       connect();

   }
   public ConnectDataBaseDB(String url, String dbName, String driver, String userName, String password) {
      this.url = url;
      this.dbName = dbName;
      this.driver = driver;
      this.userName = userName;
      this.password = password;
   }

   private void connect() throws SQLException {
      if (conn != null) {
         return;
      }
      try {
         Class.forName(driver);
      } catch (ClassNotFoundException e) {
         throw new SQLException("Driver not found");
      }
      conn = DriverManager.getConnection(url + dbName, userName, password);
   }

   public void disconnect() throws SQLException {
      if (conn != null) {
         conn.close();
         conn = null;
      }
   }

   public void executeQuery(String sql) throws SQLException {
      connect();
      Statement statement = conn.createStatement();
      statement.executeQuery(sql);
      statement.close();
   }

   public void executeUpdate(String sql) throws SQLException {
      connect();
      Statement statement = conn.createStatement();
      statement.executeUpdate(sql);
      statement.close();
      
   }

   public ResultSet executeSelect(String sql) throws SQLException {
      connect();
      Statement statement = conn.createStatement();
      ResultSet resultSet = statement.executeQuery(sql);
      return resultSet;
   }
    public static void main(String[] args) throws SQLException {
        ConnectDataBaseDB cn=new ConnectDataBaseDB();
        if(cn.conn==null)
        {
            System.out.println("Kết nối thất bạii");
        }
        else
            System.out.println("Kêt nối thành công");
        String sql="Select * from sinhvien";
        ResultSet rs=cn.executeSelect(sql);
        while (rs.next()) {
                System.out.println(rs.getInt(1) + "  " + rs.getInt(2) 
                         );
                //hien thi len textfild
              
            }
        
//        // xoa du lieu
//        String delsql = "DELETE FROM sinhvien WHERE mssv = 6";
//        cn.executeUpdate(delsql);
//        rs = cn.executeSelect(sql);
//        while (rs.next()) {
//                System.out.println(rs.getInt(1) + "  " + rs.getInt(2) 
//                         );
//        }
//        
//        //sua du lieu
//        int ten=11111;
//        int mssv=5;
//                
//      String updateSql = String.format("UPDATE sinhvien SET ten=%d WHERE mssv =%d ",ten, mssv);
//        
//        cn.executeUpdate(updateSql);
//        rs = cn.executeSelect(sql);
//        while (rs.next()) {
//            System.out.println(rs.getInt(1) + "  " + rs.getInt(2));
//        }

        // them du lieu
        int mssv=6;
        int ten= 01010;
        String insertSql= String.format("INSERT INTO sinhvien(mssv,ten) VALUES('%d','%d')",mssv,ten);
        cn.executeUpdate(insertSql);
        while(rs.next()){
            System.out.println(rs.getInt(1) + " " + rs.getInt(2));
        }
    }
    
}