/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author PC
 */

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/**
 *
 * @author Admin
 */

public class JPaneldemo extends JPanel {
    private JLabel lb1;
    private JButton bt1;
    private JTextField txt1;

    public JPaneldemo() {
        this.setBackground(Color.YELLOW);
        lb1 = new JLabel("Ten");
        txt1 = new JTextField(10);
        bt1 = new JButton("X");

        add(lb1);
        add(txt1);
        add(bt1);
    }

    public static void main(String[] args) {
            JFrame frame = new JFrame("JPaneldemo");
            JPaneldemo panel = new JPaneldemo();
            frame.add(panel);

            frame.setVisible(true);
        }
}

    

