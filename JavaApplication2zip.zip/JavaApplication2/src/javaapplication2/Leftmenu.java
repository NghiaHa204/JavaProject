/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

/**
 *
 * @author PC
 */

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import javax.swing.*;

public class Leftmenu extends JPanel implements MouseListener{
    private int WIDTH, HEIGHT;
    private JLabel[] lbls;
    ArrayList<String> list;
    
    public Leftmenu(int width,int height){
        WIDTH = width;
        HEIGHT = height;
        initComonent();
    }
    
    void initComonent(){

        list = new ArrayList<String>();
        list.add("Nhân Viên");
        list.add("Form Demo");
        list.add("Nhà Cung Cấp");
        list.add("Phiếu Nhập");
        list.add("Nhân Viên");
        list.add("Sản Phẩm");
        list.add("Nhà Cung Cấp");
        list.add("Phiếu Xuất");
        list.add("ABC");
        list.add("Nhân Viên");
        list.add("Sản Phẩm");
        list.add("Nhà Cung Cấp");
        
        this.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        createJlabel();
        
    }
    public void createJlabel(){
        this.setLayout(new FlowLayout(0,5,5));
        lbls = new JLabel[list.size()];
        for (int i = 0; i< list.size(); i++)
        {
            lbls[i] = new JLabel(list.get(i));
            lbls[i].setPreferredSize(new Dimension(WIDTH, 30));
            lbls[i].setBackground(Color.GREEN);
            
            lbls[i].setOpaque(true);
            this.add(lbls[i]);
            lbls[i].addMouseListener(this);
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mousePressed(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        JLabel src = (JLabel) e.getSource();
        System.out.print(src.getText());
        if (src.getText().equals("Nhân Viên")){
            src.setBackground(Color.red);
            src.setOpaque(true);
        }
        else if(src.getText().equals("Nhà Cung Cấp")){
            src.setBackground(Color.red);
            src.setOpaque(true);
        }
        else if(src.getText().equals("Sản Phẩm")){
            src.setBackground(Color.red);
            src.setOpaque(true);
        }
        else if(src.getText().equals("Phiếu Nhập")){
            src.setBackground(Color.red);
            src.setOpaque(true);
        }
        else if(src.getText().equals("Phiếu Xuất")){
            src.setBackground(Color.red);
            src.setOpaque(true);
        }
        else 
            System.out.print("Khong Phai");
    }

    @Override
    public void mouseExited(MouseEvent e) {
        JLabel src = (JLabel)e.getSource();
        src.setBackground(Color.GREEN);
    }
    public static void main(String[]args){
        JFrame frame = new JFrame("JPaneldemo");
            Leftmenu lm = new Leftmenu(300,300);
            frame.add(lm);

            frame.setVisible(true);
    }

    private Object setPreferredSize() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
