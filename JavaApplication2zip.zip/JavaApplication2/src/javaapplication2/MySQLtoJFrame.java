/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication2;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class MySQLtoJFrame extends JFrame {
    private JTable table;

    public MySQLtoJFrame() {
        setTitle("Data from MySQL");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/nhanvien1", "username", "password");

            DatabaseMetaData metaData = conn.getMetaData();
            ResultSet rsColumns = metaData.getColumns(null, null, "nhanvien1", null);

            // Get column names
            int columnCount = 0;
            while (rsColumns.next()) {
                columnCount++;
            }
            String[] columnNames = new String[columnCount];
            rsColumns.beforeFirst(); // Reset cursor
            int i = 0;
            while (rsColumns.next()) {
                columnNames[i++] = rsColumns.getString("COLUMN_NAME");
            }

            // Fetch data
            Statement stmt = conn.createStatement();
            ResultSet rsData = stmt.executeQuery("SELECT * FROM nhanvien1");

            // Count rows
            int rowCount = 0;
            while (rsData.next()) {
                rowCount++;
            }

            // Create data array
            Object[][] data = new Object[rowCount][columnCount];
            rsData.beforeFirst(); // Reset cursor
            i = 0;
            while (rsData.next()) {
                for (int j = 0; j < columnCount; j++) {
                    data[i][j] = rsData.getObject(j + 1); // Columns are 1-indexed
                }
                i++;
            }

            conn.close();

            // Create JTable with data
            table = new JTable(data, columnNames);
            JScrollPane scrollPane = new JScrollPane(table);
            getContentPane().add(scrollPane, BorderLayout.CENTER);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            MySQLtoJFrame frame = new MySQLtoJFrame();
            frame.setVisible(true);
        });
    }
}
