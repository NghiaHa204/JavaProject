package javaapplication2;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Nhanvien extends JFrame {
    private DefaultTableModel model;
    private JPanel p1;
    private JPanel p2;
    private JPanel p3;
    private JPanel p4;
    private JPanel p5;

    private JButton btthem, btxoa, btsua,bttimkiem;
    private JLabel lbmssv, lbhoten, lbdiachi, lbhinh;
    private JTextField txtmssv, txthoten, txtdiachi, txthinh, txttimkiem;

    public Nhanvien() {
        init();
    }

    void init() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("Quản lý nhân viên");
        setLayout(new BorderLayout(5, 5));
        setSize(800, 600);
        
        // Khởi tạo mô hình dữ liệu cho bảng
        model = new DefaultTableModel();
        String[] columnNames = {"Mã Sinh viên", "Họ và Tên", "Địa chỉ", "Hình"};
        model.setColumnIdentifiers(columnNames);

        // Panel p1
        p1 = new JPanel();
        p1.setBackground(Color.RED);
        p1.setPreferredSize(new Dimension(300, 100));

        btthem = new JButton("Thêm");
        btsua = new JButton("Sửa");
        btxoa = new JButton("Xóa");
        bttimkiem = new JButton("Tìm kiếm");
        txttimkiem = new JTextField(20);
        
        
        p1.add(btthem);
        p1.add(btxoa);
        p1.add(btsua);
        p1.add(bttimkiem);
        p1.add(txttimkiem); 
        
        
        
        

        // Panel p2
        p2 = new JPanel();
        p2.setBackground(Color.BLUE);
        p2.setPreferredSize(new Dimension(200, 100));

        // Panel p3
        p3 = new JPanel();
        p3.setBackground(Color.CYAN);
        p3.setLayout(new BorderLayout());

        JTable table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        p3.add(sp, BorderLayout.CENTER);

        // Panel p4
        p4 = new JPanel();
        p4.setLayout(new BorderLayout());
        p4.setBackground(Color.WHITE);

        // Panel p5
        p5 = new JPanel();
        p5.setLayout(new GridLayout(4, 2, 3, 3)); // 4 hàng, 2 cột, rộng 3, dài 3
        p5.setBackground(Color.PINK);
        p5.setPreferredSize(new Dimension(100, 20));

        lbmssv = new JLabel("Mã Sinh Viên");
        lbhoten = new JLabel("Họ và Tên");
        lbdiachi = new JLabel("Địa Chỉ");
        lbhinh = new JLabel("Hình");

        txtmssv = new JTextField(20);
        txthoten = new JTextField(20);
        txtdiachi = new JTextField(20);
        txthinh = new JTextField(20);

        p5.add(lbmssv);
        p5.add(txtmssv);
        p5.add(lbhoten);
        p5.add(txthoten);
        p5.add(lbdiachi);
        p5.add(txtdiachi);
        p5.add(lbhinh);
        p5.add(txthinh);

        p4.add(p1, BorderLayout.EAST);
        p4.add(p2, BorderLayout.WEST);
        p4.add(p5, BorderLayout.CENTER);
        p4.add(p3, BorderLayout.SOUTH);

        add(p4, BorderLayout.CENTER);

        // Hiển thị cửa sổ
        setVisible(true);

        
        // Thực hiện thêm dữ liệu vào cơ sở dữ liệu
        btthem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Lấy thông tin từ các trường nhập liệu
                int mssv = Integer.parseInt(txtmssv.getText());
                String hoten = txthoten.getText();
                String diachi = txtdiachi.getText();
                String hinh = txthinh.getText();
                try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "")) {
                    String query = "INSERT INTO nhanvien1 (mssv, hoten, diaChi, hinh) VALUES (?, ?, ?, ?)";
                    try (PreparedStatement statement = connection.prepareStatement(query)) {
                        // Thiết lập giá trị của tham số trong câu lệnh SQL
                        statement.setInt(1, mssv);
                        statement.setString(2, hoten);
                        statement.setString(3, diachi);
                        statement.setString(4, hinh);
                        statement.executeUpdate();
                        model.addRow(new Object[]{mssv, hoten, diachi, hinh});
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "Lỗi khi thêm nhân viên: " + ex.getMessage());
                }
            }
        });

        // Thực hiện sửa dữ liệu trong cơ sở dữ liệu
        btsua.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    // Lấy thông tin từ các TextField
                    int mssv = Integer.parseInt(txtmssv.getText());
                    String hoten = txthoten.getText();
                    String diachi = txtdiachi.getText();
                    String hinh = txthinh.getText();
                    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "")) {  
                        String query = "UPDATE nhanvien1 SET hoten = ?, diaChi = ?, hinh = ? WHERE mssv = ?";
                        try (PreparedStatement statement = connection.prepareStatement(query)) {
                            // Thiết lập giá trị của tham số trong câu lệnh SQL
                            statement.setString(1, hoten);
                            statement.setString(2, diachi);
                            statement.setString(3, hinh);
                            statement.setInt(4, mssv);
                            statement.executeUpdate();
                            model.setValueAt(hoten, selectedRow, 1);
                            model.setValueAt(diachi, selectedRow, 2);
                            model.setValueAt(hinh, selectedRow, 3);
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Lỗi khi sửa nhân viên: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Vui lòng chọn một nhân viên để sửa.");
                }
            }
        });


        
        // Thực hiện xóa dữ liệu từ cơ sở dữ liệu
        btxoa.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow != -1) {
                    int mssv = (int) model.getValueAt(selectedRow, 0);
                    try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "")) {                        // Câu lệnh SQL để xóa dữ liệu từ bảng nhanvien1 dựa trên mssv
                        String query = "DELETE FROM nhanvien1 WHERE mssv = ?";
                        try (PreparedStatement statement = connection.prepareStatement(query)) {
                            statement.setInt(1, mssv);
                            statement.executeUpdate();
                            model.removeRow(selectedRow);
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(null, "Lỗi khi xóa nhân viên: " + ex.getMessage());
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Vui lòng chọn một nhân viên để xóa.");
                }
            }
        });
    
        //hien thi table
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "")) {
            String query = "SELECT * FROM nhanvien1";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {
                while (resultSet.next()) {
                    int mssv = resultSet.getInt("mssv");
                    String hoten = resultSet.getString("hoten");
                    String diachi = resultSet.getString("diaChi");
                    String hinh = resultSet.getString("hinh");

                    // Thêm dòng mới vào mô hình dữ liệu của JTable
                    model.addRow(new Object[]{mssv, hoten, diachi, hinh});
                }
            } 
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
       Nhanvien bd = new Nhanvien();
    }
}
