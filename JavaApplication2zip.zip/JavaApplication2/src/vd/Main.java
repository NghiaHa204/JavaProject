/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vd;

/**
 *
 * @author PC
 */
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Tạo khung JFrame chính
        JFrame frame = new JFrame("Quản Lý Nhân Viên");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 600);
        
        // Tạo JPanel NhanVien và thêm vào JFrame
        NhanVien panel = new NhanVien(frame);
        frame.add(panel);
        
        // Hiển thị JFrame
        frame.setVisible(true);
    }
}

