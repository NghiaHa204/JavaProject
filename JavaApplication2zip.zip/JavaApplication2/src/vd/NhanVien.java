/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vd;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.table.DefaultTableModel;

public class NhanVien extends JPanel {
    private JButton btthem, btxoa, btsua, btChiTiet;
    JTable table;
    private DefaultTableModel tableModel;
    
    public NhanVien(JFrame parentFrame) {
        setLayout(new BorderLayout());
        
        // Panel p1 chứa các nút thao tác
        JPanel p1 = new JPanel();
        p1.setLayout(new FlowLayout(FlowLayout.LEFT));

        // Thêm các nút và thiết lập các hành động
        btthem = new JButton("Thêm");
        btthem.addActionListener(e -> showFormDialog(parentFrame, "Thêm"));
        
        btxoa = new JButton("Xóa");
        btxoa.addActionListener(e -> showFormDialog(parentFrame, "Xóa"));

        btsua = new JButton("Sửa");
        btsua.addActionListener(e -> showFormDialog(parentFrame, "Sửa"));

        btChiTiet = new JButton("Chi Tiết");
        btChiTiet.addActionListener(e -> showDetailsDialog(parentFrame));

        // Thêm các nút vào panel p1
        p1.add(btthem);
        p1.add(btxoa);
        p1.add(btsua);
        p1.add(btChiTiet);
        
        // Thêm p1 vào JPanel chính
        add(p1, BorderLayout.NORTH);
        
        // Bảng để hiển thị danh sách nhân viên
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Age", "Position"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        
        // Thêm bảng vào JPanel chính
        add(scrollPane, BorderLayout.CENTER);
    }

    // Phương thức để hiển thị FormInput khi nhấp vào các nút Thêm, Xóa, hoặc Sửa
    private void showFormDialog(JFrame parentFrame, String actionType) {
        FormInput form = new FormInput(parentFrame, actionType, this);
        form.setVisible(true);
    }
    
    // Phương thức để hiển thị dialog chi tiết nhân viên (nếu cần)
    private void showDetailsDialog(JFrame parentFrame) {
        // Hiển thị chi tiết nhân viên
    }
    
    // Phương thức để thêm nhân viên vào bảng (được gọi từ FormInput)
    public void addEmployee(int id, String name, int age, String position) {
        tableModel.addRow(new Object[]{id, name, age, position});
    }
    
    // Phương thức để sửa thông tin nhân viên (được gọi từ FormInput)
    public void updateEmployee(int row, int id, String name, int age, String position) {
        tableModel.setValueAt(id, row, 0);
        tableModel.setValueAt(name, row, 1);
        tableModel.setValueAt(age, row, 2);
        tableModel.setValueAt(position, row, 3);
    }
    
    // Phương thức để xóa nhân viên (được gọi từ FormInput)
    public void deleteEmployee(int row) {
        tableModel.removeRow(row);
    }
}
