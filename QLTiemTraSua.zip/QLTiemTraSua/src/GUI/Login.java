package GUI;

import BUS.PhanQuyenBUS;
import BUS.TaiKhoanBUS;
import DAO.ConnectDataBaseDB;
import DTO.PhanQuyenDTO;
import DTO.TaiKhoanDTO;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;

public class Login extends JFrame {
    private Font titleFont = new Font("Times New Roman", Font.BOLD, 30);
    private Font fieldFont = new Font("Times New Roman", Font.PLAIN, 16);
    private JComponent[] components;
    private TaiKhoanBUS tkBUS;
    private PhanQuyenBUS pqBUS;
    private ConnectDataBaseDB conn;

    public void init() {
        pqBUS = new PhanQuyenBUS();
        tkBUS = new TaiKhoanBUS();
        components = new JComponent[3];
        JPanel container = new JPanel(new GridLayout(3, 1));
        this.setLayout(new FlowLayout());
        ImageIcon backgroundImg = new ImageIcon("img/loginBackground.jpg");
        JLabel backgroundImageLabel = new JLabel(backgroundImg);

        JPanel backgroundImagePanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Image image = backgroundImg.getImage();
                g.drawImage(image, 0, 0, 600, 350, this);
            }
        };
        backgroundImagePanel.setLayout(null);

        components[0] = new JLabel("ĐĂNG NHẬP", JLabel.CENTER);
        components[0].setForeground(Color.black);
        components[0].setFont(titleFont);
        components[0].setOpaque(false);
        this.setTitle("LOGIN");

        components[1] = new JPanel(new FlowLayout(FlowLayout.CENTER, 100, 10));
        JTextField usernameTextField = new JTextField("admin");
        JPasswordField passField = new JPasswordField("admin");
        usernameTextField.setPreferredSize(new Dimension(250, 35));
        passField.setPreferredSize(new Dimension(250, 35));
        usernameTextField.setFont(fieldFont);
        passField.setFont(fieldFont);
        components[1].add(usernameTextField);
        components[1].add(passField);
        components[1].setOpaque(false);

        components[2] = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JButton loginButton = new JButton("XÁC NHẬN");
        loginButton.setPreferredSize(new Dimension(90, 40));

        loginButton.addActionListener(e -> {
            String username = usernameTextField.getText();
            char[] passwordChars = passField.getPassword();
            String password = new String(passwordChars);

            if (tkBUS.checkLogin(username, password)) {
                TaiKhoanDTO tkDTO = tkBUS.getTaiKhoan(username, password);
                int idQuyen = tkDTO.getIdQuyen();
                PhanQuyenDTO pqDTO = pqBUS.getIdvsTen(idQuyen);
                String tenTK = pqDTO.getTen();
                int idQ = pqDTO.getIdQuyen();
                dispose();
                GUI.Main menu = new GUI.Main(tenTK, idQ);
                menu.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Tên đăng nhập hoặc mật khẩu không đúng");
            }
        });

        loginButton.setBackground(Color.white);
        loginButton.setBorder(BorderFactory.createLineBorder(Color.WHITE, 3));
        components[2].add(loginButton);
        components[2].setOpaque(false);

        container.add(components[2]);

        JButton forgotPasswordButton = new JButton("Quên mật khẩu");
        forgotPasswordButton.setPreferredSize(new Dimension(90, 40));

        forgotPasswordButton.addActionListener(e -> showForgotPasswordDialog());

        components[2].add(forgotPasswordButton);
        components[2].setOpaque(false);

        for (JComponent component : components) {
            container.add(component);
        }

        container.setBounds(0, 0, 600, 350);
        container.setOpaque(false);
        backgroundImagePanel.add(container);
        this.setSize(600, 350);
        this.setContentPane(backgroundImagePanel);

        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setVisible(true);
    }

    private void showForgotPasswordDialog() {
        JFrame forgotPasswordFrame = new JFrame("Quên mật khẩu");
        forgotPasswordFrame.setSize(400, 200);
        forgotPasswordFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        forgotPasswordFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        JLabel label = new JLabel("Nhập địa chỉ email để thiết lập lại mật khẩu:");
        JTextField emailField = new JTextField(20);
        JButton confirmButton = new JButton("Xác nhận");

        confirmButton.addActionListener(e -> {
            String userEmail = emailField.getText();
            if (isValidEmail(userEmail)) {
                String newPassword = generateRandomPassword(8);
                boolean success = sendNewPassword(userEmail, newPassword);
                if (success) {
                    JOptionPane.showMessageDialog(null, "Mật khẩu mới đã được gửi đến địa chỉ email của bạn.");
                    forgotPasswordFrame.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Có lỗi xảy ra. Vui lòng thử lại sau.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Địa chỉ email không hợp lệ. Vui lòng nhập lại.");
            }
        });

        panel.add(label);
        panel.add(emailField);
        panel.add(confirmButton);

        forgotPasswordFrame.add(panel);
        forgotPasswordFrame.setVisible(true);
        // Mở cửa sổ đăng nhập lại
        forgotPasswordFrame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                // Hiển thị cửa sổ đăng nhập lại khi cửa sổ quên mật khẩu được đóng lại
                setVisible(true);
            }
        });
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    private String generateRandomPassword(int length) {
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+";
        StringBuilder newPassword = new StringBuilder();

        // Tạo mật khẩu ngẫu nhiên bằng cách chọn ngẫu nhiên ký tự từ 'characters' và thêm vào newPassword
        for (int i = 0; i < length; i++) {
            int index = (int) (Math.random() * characters.length());
            newPassword.append(characters.charAt(index));
        }

        return newPassword.toString();
    }

    private boolean sendNewPassword(String userEmail, String newPassword) {
        final String username = "ntmthi.0234@gmail.com"; // Thay bằng địa chỉ email của bạn
        final String password = "qqeu sjmy rxmp sasn"; // Thay bằng mật khẩu email của bạn

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(username));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(userEmail));
            message.setSubject("Mật khẩu mới của bạn");
            message.setText("Chào bạn,\n\n"
                    + "Mật khẩu mới của bạn là: " + newPassword);
            Transport.send(message);
            System.out.println("Email sent successfully!");

            // Kết nối cơ sở dữ liệu và cập nhật mật khẩu mới
            boolean updateSuccess = updatePassword(userEmail, newPassword);
            return updateSuccess;
        } catch (MessagingException ex) {
            ex.printStackTrace();
            return false;
        }
    }

    private boolean updatePassword(String email, String newPassword) {
        try {
            // Kiểm tra xem email và mật khẩu mới có khả năng null hay không
            if (email == null || newPassword == null || email.isEmpty() || newPassword.isEmpty()) {
                System.err.println("Email hoặc mật khẩu mới không hợp lệ.");
                return false;
            }

            // Kết nối cơ sở dữ liệu và thực hiện cập nhật mật khẩu mới
            Connection connection = conn.getConnection();
            if (connection == null) {
                System.err.println("Không thể kết nối đến cơ sở dữ liệu.");
                return false;
            }

            String sql = "UPDATE taikhoan SET passWord = ? WHERE gmail = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, newPassword);
            statement.setString(2, email);
            int rowsUpdated = statement.executeUpdate();
            statement.close();
            connection.close();

            if (rowsUpdated > 0) {
                System.out.println("Mật khẩu đã được cập nhật trong cơ sở dữ liệu.");
                return true;
            } else {
                System.err.println("Không có dòng nào được cập nhật trong cơ sở dữ liệu.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Login() throws SQLException {
        conn = new ConnectDataBaseDB();
        init();
    }

    public static void main(String[] args) {
        try {
            Login login = new Login();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
