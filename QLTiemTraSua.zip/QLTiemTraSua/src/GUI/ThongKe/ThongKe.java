package GUI.ThongKe;


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Calendar;



public class ThongKe extends JPanel{
    public static final int width = 1138, height = 699;
    private JPanel cardPanel;
    CardLayout cardLayout;
    JPanel top,center, cenTitle, cenMain;
    JComboBox<String> quy;
    JComboBox<Integer> nam;
    JLabel title;
    JLabel lbQuy, lbNam;
    ThongKeDT tkdt;
    ThongKeSP tksp;
    
    public ThongKe(){
        initComponent();
    }
    void initComponent(){
        this.setBackground(Color.WHITE);
        this.setLayout(new BorderLayout());
        top = new JPanel();
        center = new JPanel();
        top.setPreferredSize(new Dimension(width,120));
        top.setLayout(new GridLayout(1,4));
        top.setBackground(Color.WHITE);
        center.setPreferredSize(new Dimension(width,579));
        center.setLayout(new BorderLayout());
        cenTitle = new JPanel();
        cenTitle.setBackground(Color.ORANGE);
        cenMain = new JPanel();
        cenMain.setBackground(Color.WHITE);
        title = new JLabel("Thống kê theo quý");
        center.add(cenTitle, BorderLayout.NORTH);
        center.add(cenMain, BorderLayout.CENTER);
        cenTitle.add(title);
        String[] data = {"Quý 1", "Quý 2", "Quý 3", "Quý 4"};
        lbQuy = new JLabel("Mời chọn quý: ");
        nam = new JComboBox<>();
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        for (int i = currentYear; i >= currentYear - 10; i--)
            nam.addItem(i);
        lbNam = new JLabel("Mời chọn năm: ");
        quy = new JComboBox<>(data);
        cenMain.add(lbQuy);
        cenMain.add(quy);
        cenMain.add(lbNam);
        cenMain.add(nam);
        
        
        // Tạo panel 0
        JPanel tk = new JPanel();
//      tk.setLayout(new FlowLayout(FlowLayout.CENTER, 150, 20));
//      tk.setLayout(new GridLayout(1, 4, 20, 20));
        tk.setPreferredSize(new Dimension(width,200));
        tk.setLayout(new BorderLayout());
        tk.add(top, BorderLayout.NORTH);
        tk.add(center, BorderLayout.CENTER);
        
        Font font = new Font("Segoe UI",Font.BOLD, 20);
            
        JLabel label1 = new JLabel("3");
        label1.setIcon(new ImageIcon("D:/NETBEANS/JAVA/QLTiemTraSua/img/tkkh.png"));
        label1.setHorizontalAlignment(JLabel.CENTER);
        label1.setVerticalAlignment(JLabel.CENTER);
        label1.setHorizontalTextPosition(SwingConstants.CENTER);
        label1.setFont(font);
        top.add(label1);

        JLabel label2 = new JLabel();
        label2.setIcon(new ImageIcon("D:/NETBEANS/JAVA/QLTiemTraSua/img/tksp.png"));
        label2.setHorizontalAlignment(JLabel.CENTER);
        label2.setVerticalAlignment(JLabel.CENTER);
        label2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(cardPanel, "panel2");
            }
        });
        top.add(label2);

        JLabel label3 = new JLabel();
        label3.setIcon(new ImageIcon("D:/NETBEANS/JAVA/QLTiemTraSua/img/tknv.png"));
        
        label3.setHorizontalAlignment(JLabel.CENTER);
        label3.setVerticalAlignment(JLabel.CENTER);
        top.add(label3);

        JLabel label4 = new JLabel();
        label4.setIcon(new ImageIcon("D:/NETBEANS/JAVA/QLTiemTraSua/img/tkdt.png"));
        label4.setHorizontalAlignment(JLabel.CENTER);
        label4.setVerticalAlignment(JLabel.CENTER);
//        label4.setOpaque(true);
        label4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                cardLayout.show(cardPanel, "panel4");
            }
        });
       top.add(label4);

        cardPanel = new JPanel();
        cardLayout = new CardLayout();
        cardPanel.setLayout(cardLayout);
        
        // Tạo panel 2
        tksp = new ThongKeSP("Panel 2", "panel0", cardLayout, cardPanel);
        // Tạo panel 4
        tkdt = new ThongKeDT("Panel 4", "panel0", cardLayout, cardPanel);

        // Tạo container chứa các panel
        cardPanel.add(tk, "panel0");
        cardPanel.add(tksp, "panel2");
        cardPanel.add(tkdt, "panel4");
        
        add(cardPanel);


    }

}

