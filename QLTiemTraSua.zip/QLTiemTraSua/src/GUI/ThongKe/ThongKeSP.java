package GUI.ThongKe;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class ThongKeSP extends JPanel {

    private String panelName;
    private String backPanelName;
    private CardLayout cardLayout;
    private JPanel cardPanel;
    JPanel top, center, topbutton, toptitle;
    JLabel title;

    public ThongKeSP(String panelName, String backPanelName, CardLayout cardLayout, JPanel cardPanel) {
    this.panelName = panelName;
    this.backPanelName = backPanelName;
    this.cardLayout = cardLayout;
    this.cardPanel = cardPanel;
    initComponent();
}


    void initComponent() {
        setLayout(new BorderLayout());
        top = new JPanel();
        center = new JPanel();
        top.setLayout(new BorderLayout());
        top.setPreferredSize(new Dimension(getWidth(), 50));
        toptitle = new JPanel(new FlowLayout(FlowLayout.CENTER,0,15));
        toptitle.setBackground(Color.YELLOW);
   
        title = new JLabel("THỐNG KÊ SẢN PHẨM");
        JButton backButton = new JButton("Quay lại");
        backButton.setBounds(0, 0, 80, 50);
        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cardLayout.show(cardPanel, backPanelName);
            }
        });
        
        toptitle.add(title);
        top.add(backButton);
        top.add(toptitle, BorderLayout.CENTER);
        add(top, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);
    }
}

