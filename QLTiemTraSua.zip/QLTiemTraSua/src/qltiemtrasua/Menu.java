package qltiemtrasua;

/**
 *
 * @author Admin
 */

import javax.swing.*;
import java.awt.*;

public class Menu extends JPanel {
    public Menu(){
        this.setBackground(Color.white);
    }
}
