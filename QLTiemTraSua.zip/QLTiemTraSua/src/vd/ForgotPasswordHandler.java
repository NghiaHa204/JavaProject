/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vd;

/**
 *
 * @author PC
 */


import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import java.security.SecureRandom;

public class ForgotPasswordHandler {
    private static final String ALLOWED_CHARACTERS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
    private static final SecureRandom random = new SecureRandom();

    // Tạo mã xác nhận ngẫu nhiên
    public static String generateConfirmationCode(int length) {
        StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(ALLOWED_CHARACTERS.length());
            char randomChar = ALLOWED_CHARACTERS.charAt(randomIndex);
            sb.append(randomChar);
        }
        return sb.toString();
    }

    // Gửi email xác nhận
    public static void sendConfirmationEmail(String recipientEmail, String confirmationCode) {
        // Cấu hình thông tin email
        final String username = "ntmthi.0234@gmail.com"; // Thay bằng địa chỉ email của bạn
        final String password = "qqeu sjmy rxmp sasn"; // Thay bằng mật khẩu email của bạn

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // Tạo phiên gửi email
        Session session = Session.getInstance(props,
                new javax.mail.Authenticator() {
                    protected PasswordAuthentication getPasswordAuthentication() {
                        return new PasswordAuthentication(username, password);
                    }
                });

        try {
            // Tạo đối tượng MimeMessage
            Message message = new MimeMessage(session);
            // Thiết lập địa chỉ email người gửi
            message.setFrom(new InternetAddress(username));
            // Thiết lập địa chỉ email người nhận
            message.setRecipients(Message.RecipientType.TO,
                    InternetAddress.parse(recipientEmail));
            // Thiết lập chủ đề của email
            message.setSubject("Xác nhận đặt lại mật khẩu");
            // Thiết lập nội dung của email
            message.setText("Chào bạn,\n\n"
                    + "Đây là mã xác nhận của bạn: " + confirmationCode);

            // Gửi email
            Transport.send(message);

            System.out.println("Email sent successfully!");

        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        // Thay thế bằng địa chỉ email của người dùng
        String recipientEmail = "thanhphat1106191@gmail.com";
        // Tạo mã xác nhận ngẫu nhiên có độ dài 6 ký tự
        String confirmationCode = generateConfirmationCode(6);
        // Gửi email xác nhận với mã xác nhận đã tạo
        sendConfirmationEmail(recipientEmail, confirmationCode);
    }
}
